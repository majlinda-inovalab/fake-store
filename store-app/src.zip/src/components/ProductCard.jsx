import React from "react";

const ProductCard = ({ product }) => {
  return (
    <>
      <div className="product">
        <div className="product-image">
          <img src={product.image} alt="Product Image" />
        </div>
        <div className="product-name">
          <h2>{product.title}</h2>
          <strong>userID:{product.id}</strong>
        </div>
      </div>
    </>
  );
};

export default ProductCard;
