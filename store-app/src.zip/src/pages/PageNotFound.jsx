import MainLayout from "../layouts/MainLayout";

const PageNotFound = () => {
  return (
    <MainLayout>
      <div></div>
    </MainLayout>
  );
};

export default PageNotFound;
