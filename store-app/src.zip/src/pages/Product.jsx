import MainLayout from "../layouts/MainLayout";

const Product = () => {
  return (
    <MainLayout>
      <div></div>
    </MainLayout>
  );
};

export default Product;
