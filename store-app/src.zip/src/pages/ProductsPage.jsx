import ProductCard from "../components/ProductCard";
import useGetPosts from "../hooks/useGetProducts";
import MainLayout from "../layouts/MainLayout";

const ProductsPage = () => {
  const { products, isLoading } = useGetPosts();

  if (isLoading) return <div>loading...</div>;
  return (
    <MainLayout>
      <div className="posts-wrap">
        {products.length > 0 ? (
          products.map((product) => (
            <ProductCard key={product.id} product={product} />
          ))
        ) : (
          <h2>No products</h2>
        )}
      </div>
    </MainLayout>
  );
};

export default ProductsPage;
